#include<iostream>
using namespace std;

typedef unsigned short word16;
typedef unsigned int word32;

int main(){
    word16 numa=16;
    word16 numb=32;
    word32 numc=64;
    cout << "numa + numb = " << numa + numb << endl;
    cout << "numc + numa = " << numc + numa << endl;
}