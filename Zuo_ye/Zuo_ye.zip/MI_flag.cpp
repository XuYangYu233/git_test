#include<stdio.h>
#include<stdlib.h>

int main(void)
{
	printf("Hello c world\n");
	printf("*           *           *\n   *        *        *\n     *      *      *\n       *    *    *\n          * * *\n* * * * * * * * * * * * *\n          * * *\n       *    *    *\n     *      *      *\n   *        *        *\n*           *           *\n");
	system("PAUSE");
	return 0;
}
